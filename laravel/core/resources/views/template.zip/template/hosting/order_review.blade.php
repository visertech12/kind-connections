@php
    $seo = config('seo.hosting.order.review', config('seo.default', []));
    $seodata['title']       = $seo['title'] ?? '';
    $seodata['description'] = $seo['description'] ?? '';
    $seodata['keyword']     = $seo['keyword'] ?? '';
    $seodata['image']       = $seo['image'] ?? '';
@endphp
@extends('template.layouts.frontend', ['seodata' => $seodata])
@section('content')

<section class="py-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                    <h2 class="section-heading__title"> Your Hosting <span class="shape"> Order Review </span> </h2>
                    <p class="section-heading__desc">Review the hosting services in your cart before proceeding to checkout.</p>
                </div>
            </div>
        </div>

        @php $tempSession = session()->get('tempOrder'); @endphp
        @php $tempOrders = $tempSession ? \App\Models\TempOrder::where('sid', $tempSession)->get() : collect(); @endphp

        @if($tempOrders->isEmpty())
            <div class="row justify-content-center mt-5">
                <div class="col-lg-6 text-center">
                    <div class="empty-state py-5">
                        <i class="fa-light fa-cart-shopping fs-60 text--base mb-4 d-block"></i>
                        <h4>Your Cart is Empty</h4>
                        <p class="section-heading__desc">You have no hosting orders pending review.</p>
                        <a href="{{route('hosting.premium')}}" class="btn btn--base mt-4">BROWSE HOSTING PLANS</a>
                    </div>
                </div>
            </div>
        @else
            <div class="row gy-4 mt-4">
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="mb-4">Order Items</h5>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Service</th>
                                            <th>Plan</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($tempOrders as $order)
                                        <tr>
                                            <td>{{$order->service ?? 'Hosting Service'}}</td>
                                            <td>{{$order->plan ?? 'Standard Plan'}}</td>
                                            <td>${{getAmount($order->amount ?? 0)}}</td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <h5 class="mb-4">Order Summary</h5>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Items ({{$tempOrders->count()}})</span>
                                <strong>${{getAmount($tempOrders->sum('amount'))}}</strong>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between mb-4">
                                <strong>Total</strong>
                                <strong class="text--base">${{getAmount($tempOrders->sum('amount'))}}</strong>
                            </div>
                            <a href="{{route('user.login')}}" class="btn btn--base w-100">PROCEED TO CHECKOUT</a>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>
</section>

@endsection
