@extends('user.layouts.app')
@section('panel')

<div class="table-card">
  <div class="table-card__inner d-flex flex-wrap flex-between align-center gap-2">
    <div class="table-card__heading">
      <h2 class="table-card__title"><span class="icon"><i class="icon-direct-purchase-outline"></i></span> My Direct Purchases</h2>
    </div> 
  </div>
  <div class="table-card__table">
    @if(isset($purchases) && $purchases->count())
    <table class="table table--responsive--xl">
      <thead>
        <tr>
          <th>Invoice ID</th>
          <th>Product</th>
          <th>Amount</th>
          <th>Purchase Date</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($purchases as $purchase)
        <tr>
          <td data-label="Invoice ID" class="fw-bold">#{{$purchase->invid}}</td>
          <td data-label="Product">
             @foreach($purchase->items as $item)
                 <div>{{ $item->description }}</div>
             @endforeach
          </td>
          <td data-label="Amount" class="font-weight-bold">${{getAmount($purchase->amount)}} USD</td>
          <td data-label="Purchase Date">{{showDateTime($purchase->created_at,'Y-m-d')}}</td>
          <td data-label="Status">{!! printInvoiceStatus($purchase->status) !!}</td>
          <td data-label="Action">
            <a href="{{route('user.invoice.details',$purchase->invid)}}" class="btn btn--base d-inline-block">Invoice</a>
          </td>
        </tr>
        @endforeach 
      </tbody>
    </table>
    @else
    <div class="not-data-found">
      <span class="not-data-found__icon">
        <i class="icon-direct-purchase-outline"></i>
      </span>
      <span class="not-data-found__text">No Direct Purchases Yet!</span>
    </div>
    @endif
  </div>
</div>
@if(isset($purchases) && $purchases->hasPages())
    {{$purchases->links('admin.partials.paginate')}}
@endif
@endsection
