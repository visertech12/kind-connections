<!-- Common features partial (Stub) -->
