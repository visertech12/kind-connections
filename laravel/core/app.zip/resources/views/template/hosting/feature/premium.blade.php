<!-- Premium features partial (Stub) -->
